# SafariMarkdown icon kit

| Asset | Pixel dimensions | Transparency |
| --- | --- | --- |
| iPhone and iPad app icon | 1024 × 1024 universal. Xcode generates the device sizes. | Opaque sRGB PNG with no alpha channel |
| macOS app icons | 16, 32, 128, 256, and 512 pt at 1× and 2× | sRGB PNGs with transparent margins around the rounded tile |
| Safari extension listing | 48, 64, 96, 128, 256, and 512 px | Color sRGB PNGs with transparent margins |
| Safari toolbar | 16, 19, 32, and 38 px | Monochrome sRGB PNGs with transparent backgrounds |

All dimensions are square. The iOS catalog supplies the default appearance and allows the system to derive additional appearances.

## Install in SafariMarkdown

1. Replace `Markdown Viewer/Shared (App)/Assets.xcassets/AppIcon.appiconset` with the matching folder in this kit.
2. Replace the images in `WebExtension/images`. The included manifest matches the current project and adds the 64 px icon. If the project manifest has since changed, copy its `icons` mapping from the kit.
3. Replace `Markdown Viewer/Shared (App)/Assets.xcassets/LargeIcon.imageset/icon-256.png` and `Markdown Viewer/Shared (App)/Resources/Icon.png` to use the new artwork in the containing app.
4. If you add a toolbar action, copy the four PNGs from `Optional Safari Toolbar` to `WebExtension/images` and reference them by size under `action.default_icon` in the Manifest V3 manifest.

## Editable artwork

`SafariMarkdown_Layered.svg` is a vector redraw of the approved artwork. It has six named layers for the background, source card, Markdown symbol, rendered page, coral fold, and page text bars. It contains vector paths and gradients and requires no fonts or external images. Open it in a vector editor and export at the pixel size you need. The shipped color PNGs use the original approved artwork.

## Apple references

- [Creating a Safari web extension](https://developer.apple.com/documentation/safariservices/creating-a-safari-web-extension)
- [Configuring your app icon using an asset catalog](https://developer.apple.com/documentation/xcode/configuring-your-app-icon)
